/**
 * An interface that gives the blueprint for the creation of a 
 * Doubly Linked Circular List.
 *
 * @author John Burns
 * @version 05/24/19
 */
public interface DLinkedList<T>
{
    void set(int index, T data);
    void addFirst(T data);
    void add(T data);
    void add(int index, T data);
    void delete(int index);
    void deleteFirst();
    void deleteLast();
    int size();
    void clear();
    boolean contains(T data);
    T get(int index);
    T getFirst();
    T getLast();
}
