import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * The test class ArrayListTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class ArrayListTest
{
    private ArayList<Integer> arrayLis1;

    /**
     * Default constructor for test class ArrayListTest
     */
    public ArrayListTest()
    {
    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @Before
    public void setUp()
    {
        arrayLis1 = new ArayList<Integer>();
        arrayLis1.add(5);
        arrayLis1.addFirst(0);
        arrayLis1.add(1, 4);
        arrayLis1.add(1, 3);
        arrayLis1.add(1, 2);
        arrayLis1.add(1, 1);
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @After
    public void tearDown()
    {
    }

    @Test
    public void addAtIndex()
    {
        arrayLis1.add(3, 20);
        assertEquals(new Integer(20), arrayLis1.get(3));
    }

    @Test
    public void add()
    {
        arrayLis1.add(11);
        assertEquals(new Integer(11), arrayLis1.get(6));
    }

    @Test
    public void addFirst()
    {
        arrayLis1.addFirst(-1);
        assertEquals(new Integer(-1), arrayLis1.get(0));
    }

    @Test
    public void clear()
    {
        arrayLis1.clear();
        assertEquals(new String("[]"), arrayLis1.toString());
    }

    @Test
    public void contains()
    {
        assertEquals(true, arrayLis1.contains(0));
        assertEquals(true, arrayLis1.contains(1));
        assertEquals(true, arrayLis1.contains(2));
        assertEquals(true, arrayLis1.contains(3));
        assertEquals(true, arrayLis1.contains(4));
        assertEquals(true, arrayLis1.contains(5));
        assertEquals(false, arrayLis1.contains(6));
    }

    @Test
    public void deleteZeroth()
    {
        arrayLis1.deleteFirst();
        
        assertEquals(new String("[1, 2, 3, 4, 5]"), arrayLis1.toString());
    }
    
    @Test
    public void deleteIndex()
    {
        arrayLis1.delete(3);
        assertEquals(new String("[0, 1, 2, 4, 5]"), arrayLis1.toString());
    }

    @Test
    public void deleteLast()
    {
        arrayLis1.deleteLast();
        assertEquals(new String("[0, 1, 2, 3, 4]"), arrayLis1.toString());
    }

    @Test
    public void set()
    {
        arrayLis1.set(0, -21);
        assertEquals(new String("[-21, 1, 2, 3, 4, 5]"), arrayLis1.toString());
    }

    @Test
    public void size()
    {
        assertEquals(6, arrayLis1.size());
    }

    @Test
    public void toStringer()
    {
        assertEquals(new String("[0, 1, 2, 3, 4, 5]"), arrayLis1.toString());
    }
}










