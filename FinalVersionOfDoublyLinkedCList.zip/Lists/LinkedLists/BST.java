
/**
 * An interface that gives the blueprint for the creation of a 
 * Binary Search Tree.
 *
 * @author John Burns
 * @version 05/24/19
 */
public interface BST<T> {
    void add(T data);
    int size();
    void clear();
    boolean contains(T data);
    T first();
    boolean isEmpty();
    T last();
}
