import java.math.BigInteger;
/**
 * A class that enables the creation of people with a first name, last name,
 * and 9 digit id number. The id number is either the number given
 * preappended with 0's or the sum of the ASCII characters with a radix of 10.
 * 
 * @author John Burns
 * @version 05/24/19
 */
public class Person implements Comparable<Person>{
    private String fName;
    private String lName;
    private String idNum;
    
    /**
     * Creates a new person witha  first name, last name, and 
     * id number.
     * @param fName The first name of the person.
     * @param lName The last name of the person.
     * @param idNum The id number of the person.
     */
    public Person(String fName, String lName, String idNum) {
        // handle letter idNums.
        StringBuilder sb = new StringBuilder();
        for (char c : idNum.toCharArray()) {
            if (Character.isLetter(c)) {//is a letter.
                sb.append((int)c);
            }
            else {//is a number.
                sb.append(c);
            }
        }
        
        BigInteger bInt = new BigInteger(sb.toString());
        idNum = new String(bInt.toString());
        
        //handle improper length idNums.
        String editNum = "";
        if (idNum.length() < 9) {//too short.
            for (int i = 0; i < 9 - idNum.length(); i++) {
                editNum += "0";
            }
            editNum += idNum;
            idNum = new String(editNum);
        }
        if (idNum.length() > 9) {//too long.
            editNum = new String(idNum.substring(0, 9));
            idNum = new String(editNum);
        }
        this.fName = fName;
        this.lName = lName;
        this.idNum = idNum;
    }
    
    /**
     * retrieves the first name of the person.
     * @return fName The first name of the person.
     */
    public String getFName() {
        return fName;
    }
    
    /**
     * retrieves the last name of the person.
     * @return lName The last name of the person.
     */
    public String getLName() {
        return lName;
    }
    
    /**
     * retrieves the id number of the person.
     * @return idNum The String representation of the id number.
     */
    public String getIdNum() {
        return idNum;
    }
    
    /**
     * Asks whether two people are actually the same.
     * @param obj The second object to check for equality.
     * @return The answer to the question.
     */
    @Override
    public boolean equals(Object obj) {
        boolean check = false;
        
        if (this == obj) {
            check = true;
        }
        else if(obj instanceof Person) {
            Person p = (Person)obj;
            if (p.getFName().equals(this.getFName()) &&
                p.getLName().equals(this.getLName()) &&
                p.getIdNum().equals(this.getIdNum())) {
                check = true;
            }
        }
        
        return check;
    }
    
    /**
     * 
     */
    @Override
    public int compareTo(Person person) {
        return Integer.parseInt(this.getIdNum()) - Integer.parseInt(person.getIdNum());     
    }
    
    /**
     * Provides a way to print the information about a person.
     * @return the overriden string representation of this class.
     */
    @Override
    public String toString() {
        return "[first name: " + getFName() + ", lastName: " + getLName() + ", idNum: " +
                getIdNum() + "]";
    }
}
