import java.util.*;
public class May21 {
    private int x;
    private static int y = 0;
    private static ArrayList<Integer> list3;
    private int id;
    
    public static void main(String[] args) {
        test2();
    }
    
    private static void pr(Object obj) {
        System.out.println(obj);
    }
    
    public May21(int id) {
        this.id = id;
    }
    
    public May21(May21 other) {
        this.id = other.id;
    }
    
    private static void printX() {
        //System.out.println(x);
    }
    
    private static void printY() {
        System.out.println(y);
    }
    
    public void setId(int id) {
        this.id = id;
    }
    
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        else if (!(obj instanceof May21)) {
            return false;
        }
        else {
            return this.id == ((May21)obj).id;
        }
    }
    
    public int getId() {
        return id;
    }
    
    private static void test2() {
        ArrayList<May21> list1 = new ArrayList<>();
        list1.add(new May21(4));
        list1.add(new May21(6));
        list1.add(new May21(7));
        ArrayList<May21> list2 = list1;
        //ArrayList<May21> list3 = new ArrayList<>(list1);
        
        ArrayList<May21> list3 = copy(list1);
        list1.get(0).setId(99);
        
        pr(list1);
        pr(list2);
        pr(list3);
    }
    
    private static ArrayList<May21> copy(ArrayList<May21> list) {
        ArrayList<May21> newList = new ArrayList<>();
        for (int i = 0; i < list.size(); i++) {
            newList.add(new May21(list.get(i)));
        }
        return newList;
    }
    
    public String toString() {
        return "Id: " + id;
    }
    
    private static void test1() {
        ArrayList<Integer> list1 = new ArrayList<Integer>();
        Integer x = 33;
        list1.add(x); list1.add(6);
        
        ArrayList<Integer> list2 = list1;
        
        list3 = new ArrayList<>(list1);
        
        pr(list1);
        pr(list2);
        pr(list3);
        
        //printY();
    }
}