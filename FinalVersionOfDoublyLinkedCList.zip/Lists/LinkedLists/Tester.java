import java.io.*;
import java.nio.charset.Charset;
import java.nio.file.*;
import java.util.*;
public class Tester {
    private static DoubleyLinkedList<String> fName = new DoubleyLinkedList<>();
    private static DoubleyLinkedList<String> lName = new DoubleyLinkedList<>();
    private static DoubleyLinkedList<String> idNum = new DoubleyLinkedList<>();
    private static final String READ_FILE = "readStrs.txt";
    private static final String ALT_READ_FILE = "permReadStrs.txt";
    private static final String WRITE_FILE = "writeStrs.txt";
    private static final Charset charset = Charset.forName("US-ASCII");
    private static Path path1 = Paths.get(READ_FILE);
    private static Path path2 = Paths.get(WRITE_FILE);
    private static Path path3 = Paths.get(ALT_READ_FILE);

    private static DoubleyLinkedList<Person> people = new DoubleyLinkedList<>();
    private static ArayList<Person> arrayPeople = new ArayList<>();
    private static BinarySearchTree<Person> treePeople = new BinarySearchTree();

    public static void main(String[] args){
        readFile();
        people();
        writeFile();
    }

    private static void readFile() {
        try {
            BufferedReader reader = Files.newBufferedReader(path1, charset);

            String txtOfLine = reader.readLine();

            if (txtOfLine.equals("type format: firstName, lastName, idNum(letters accepted) -- if this line is here the" +
                " reader will use the permReadStrs.txt file.")) {
                reader.close();
                reader = Files.newBufferedReader(path3, charset);
            }
            
            txtOfLine = reader.readLine();

            while (txtOfLine != null) {
                if (!txtOfLine.equals("") || !txtOfLine.equals("\n")) {
                    if (txtOfLine.startsWith("[")) {
                        txtOfLine = txtOfLine.substring(1);
                    }
                    if (txtOfLine.endsWith("]")) {
                        txtOfLine = txtOfLine.substring(0, txtOfLine.lastIndexOf("]"));
                    }
                    txtOfLine = txtOfLine.trim();

                    String firstName = txtOfLine.substring(0, txtOfLine.indexOf(",")).trim();
                    String lastName = txtOfLine.substring(txtOfLine.indexOf(",") + 1, txtOfLine.lastIndexOf(",")).trim();
                    String idNumber = txtOfLine.substring(txtOfLine.lastIndexOf(",") + 1, txtOfLine.length()).trim();
                    
                    if (firstName == null) {
                        firstName = "That's";
                    }
                    
                    if (lastName == null) {
                        lastName = "improper";
                    }
                    
                    if (idNumber == null) {
                        idNumber = new Integer(1).toString();
                    }
                    
                    
                    fName.add(firstName);
                    lName.add(lastName);
                    idNum.add(idNumber);
                }
                if (fName.get(0) != null && lName.get(0) != null && idNum.get(0) != null) {
                    txtOfLine = reader.readLine();
                }
            }

            reader.close();
        }
        catch(FileNotFoundException e) {
            System.err.println("Unable to open " + READ_FILE);
        }
        catch(IOException e) {
            System.err.println("A problem was encountered reading " +
                READ_FILE);
        }
    }

    private static void writeFile() {
        try {
            BufferedWriter writer = Files.newBufferedWriter(path2, charset, StandardOpenOption.WRITE);
            writer = Files.newBufferedWriter(path2, charset, StandardOpenOption.TRUNCATE_EXISTING);
            
            Iterator<Person> it = people.iterator();
            while (it.hasNext()) {
                writer.write(it.next().toString());
                writer.newLine();
            }

            BufferedWriter writer2 = Files.newBufferedWriter(path1, charset, StandardOpenOption.WRITE);
            writer2 = Files.newBufferedWriter(path1, charset, StandardOpenOption.TRUNCATE_EXISTING);
            writer2 = Files.newBufferedWriter(path1, charset, StandardOpenOption.WRITE);
            writer2.write("type format: firstName, lastName, idNum(letters accepted) -- if this line is here the" +
                " reader will use the permReadStrs.txt file.");
            writer2.close();
            writer.close();
        }
        catch(FileNotFoundException e) {
            System.err.println("Unable to open " + WRITE_FILE);
        }
        catch(IOException e) {
            System.err.println("A problem was encountered writing " +
                WRITE_FILE);
        }
    }

    private static void peopleCreation(String type, Person person) {
        if (type.equals("set")) {
            people.set(0, person);
            arrayPeople.set(0, person);
        }
        else if (type.equals("first")) {
            people.addFirst(person);
            arrayPeople.addFirst(person);
        }
        else if (type.equals("regular")) {
            people.add(person);
            arrayPeople.add(person);
        }
        treePeople.add(person);
        prints();
    }

    private static void prints() {
        System.out.println(people);
        System.out.println(arrayPeople);
        System.out.println(treePeople);
        System.out.println();
    }

    private static void people(){
        if (people.size() > 0 && arrayPeople.size() > 0 && !treePeople.isEmpty()) {
            Person one = new Person(fName.get(0), lName.get(0), idNum.get(0));
            peopleCreation("set", one);
        }
        
            if (people.size() > 1 && arrayPeople.size() > 1 && treePeople.size() > 1) {
                Person two = new Person(fName.get(1), lName.get(1), idNum.get(1));
                peopleCreation("first", two);
            }
            for (int i = 2; i < fName.size(); i++) {
                Person person = new Person(fName.get(i), lName.get(i), idNum.get(i));
                peopleCreation("regular", person);
            }
    
            if (people.size() > 5 && arrayPeople.size() > 5 && treePeople.size() > 5) {
                peopleCreation("set", new Person(fName.get(5), lName.get(5), idNum.get(5)));
            }
            
            if (people.size() > 1 && arrayPeople.size() > 1 && treePeople.size() > 1) {
                people.deleteLast();
                arrayPeople.deleteLast();
                prints();
            }
    
            if (people.size() > 4 && arrayPeople.size() > 4 && treePeople.size() > 4) {
                people.delete(4);
                arrayPeople.delete(4);
                prints();
            }
    
            if (people.size() > 2 && arrayPeople.size() > 2 && treePeople.size() > 2) {
                Person person = new Person(fName.get(2), lName.get(2), idNum.get(2));
                System.out.println(people.contains(person));
                System.out.println(arrayPeople.contains(person));
                System.out.println(treePeople.contains(person));
            }
    
            if (people.size() > 0 && arrayPeople.size() > 0 && !treePeople.isEmpty()) {
                people.deleteFirst();
                arrayPeople.deleteFirst();
                prints();
            }
            
            System.out.println(people.size());
            System.out.println(arrayPeople.size());
            System.out.println(treePeople.size());
            System.out.println();
    
            if (people.size() > 0 && arrayPeople.size() > 0 && !treePeople.isEmpty()) {
                System.out.println(people.getFirst());
                System.out.println(arrayPeople.get(0));
                System.out.println(treePeople.first());
                System.out.println();
            }
    
            if (people.size() > 1 && arrayPeople.size() > 1 && treePeople.size() > 1) {
                System.out.println(people.getLast());
                System.out.println(arrayPeople.get(arrayPeople.size() - 1));
                System.out.println(treePeople.last());
                System.out.println();
            }
    
            Iterator<Person> it = people.iterator();
            while (it.hasNext()) {
                Person person = it.next();
                if (person.equals(new Person(fName.get(2), lName.get(2), idNum.get(2)))) {
                    it.remove();
                }
            else {
                System.out.println(person);
            }
        }
        System.out.println(people);

        System.out.println();
    }
}
