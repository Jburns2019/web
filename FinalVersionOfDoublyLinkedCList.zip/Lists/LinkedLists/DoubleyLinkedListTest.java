import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import java.util.*;

/**
 * The test class DoubleyLinkedListTest.
 */
public class DoubleyLinkedListTest
{
    private DoubleyLinkedList<Integer> doubleyL1;

    /**
     * Default constructor for test class DoubleyLinkedListTest
     */
    public DoubleyLinkedListTest() {
    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @Before
    public void setUp() {
        doubleyL1 = new DoubleyLinkedList<Integer>();
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @After
    public void tearDown() {
    }

    /**
     * Tests the set(index, T) method of the class.
     */
    @Test
    public void set()
    {
        doubleyL1.set(0, 1);
        assertEquals(new Integer(1), doubleyL1.get(0));
    }

    /**
     * Tests the addFirst(T) method of the class.
     */
    @Test
    public void addFirst()
    {
        doubleyL1.set(0, 2);
        doubleyL1.addFirst(1);
        doubleyL1.addFirst(0);
        assertEquals(new Integer(0), doubleyL1.get(0));
        assertEquals(new Integer(1), doubleyL1.get(1));
        assertEquals(new Integer(2), doubleyL1.get(2));
    }

    /**
     * Tests the add(T) method of the class.
     */
    @Test
    public void add()
    {
        doubleyL1.set(0, 0);
        doubleyL1.add(1);
        doubleyL1.add(2);
        assertEquals(new Integer(0), doubleyL1.get(0));
        assertEquals(new Integer(1), doubleyL1.get(1));
        assertEquals(new Integer(2), doubleyL1.get(2));
    }

    /**
     * Tests the deleteFirst() method of the class.
     */
    @Test
    public void deleteFirst()
    {
        doubleyL1.set(0, 0);
        doubleyL1.deleteFirst();
        assertEquals(null, doubleyL1.getFirst());
    }

    /**
     * Tests the size() method of the class.
     */
    @Test
    public void size()
    {
        assertEquals(1, doubleyL1.size());
        doubleyL1.add(1);
        doubleyL1.add(2);
        assertEquals(2, doubleyL1.size());
    }

    /**
     * Tests the delete(index) method of the class.
     */
    @Test
    public void delete()
    {
        doubleyL1.add(1);
        doubleyL1.add(2);
        doubleyL1.add(3);
        doubleyL1.delete(1);
        assertEquals(new Integer(1), doubleyL1.get(0));
        assertEquals(new Integer(3), doubleyL1.getLast());
        doubleyL1.delete(0);
        assertEquals(new Integer(3), doubleyL1.getFirst());
        doubleyL1.addFirst(1);
        doubleyL1.delete(1);
        assertEquals(new Integer(1), doubleyL1.getFirst());
    }

    /**
     * Tests the clear() method of the class.
     */
    @Test
    public void clear()
    {
        doubleyL1.add(0);
        doubleyL1.add(1);
        doubleyL1.add(2);
        doubleyL1.clear();
        assertEquals(1, doubleyL1.size());
        assertEquals(null, doubleyL1.get(0));
        assertEquals(null, doubleyL1.get(1));
        assertEquals(null, doubleyL1.get(2));
    }

    /**
     * Tests the contains(T) method of the class.
     */
    @Test
    public void contains()
    {
        doubleyL1.add(0);
        doubleyL1.add(1);
        doubleyL1.add(2);
        doubleyL1.add(3);
        assertEquals(true, doubleyL1.contains(0));
        assertEquals(true, doubleyL1.contains(1));
        assertEquals(true, doubleyL1.contains(2));
        assertEquals(true, doubleyL1.contains(3));
    }

    /**
     * Tests the add(index, T) method of the class.
     */
    @Test
    public void specialAdd()
    {
        doubleyL1.add(0, 0);
        doubleyL1.add(1, 3);
        doubleyL1.add(1, 2);
        doubleyL1.add(1, 1);
        assertEquals(new Integer(0), doubleyL1.getFirst());
        assertEquals(new Integer(3), doubleyL1.getLast());
        assertEquals(new Integer(1), doubleyL1.get(1));
        assertEquals(new Integer(2), doubleyL1.get(2));
    }

    /**
     * Tests iterator features of the class.
     */
    @Test
    public void Iterator()
    {
        ArrayList<Integer> vals = new ArrayList<>();
        doubleyL1.add(0);
        doubleyL1.add(1);
        doubleyL1.add(2);
        doubleyL1.add(3);
        doubleyL1.add(4);
        
        Iterator<Integer> it = doubleyL1.iterator();
        while (it.hasNext()) {
            Integer val = it.next();
            vals.add(val);
        }
        
        for (int i = 0; i < vals.size(); i++) {
            assertEquals(new Integer(i), vals.get(i));
        }
    }
}