public interface ArrayBasedList<T> {
    void add(T data);
    void addFirst(T data);
    void add(int index, T data);
    void set(int index, T data);
    T get(int index);
    void delete(int index);
    void deleteFirst();
    void deleteLast();
    int size();
    void clear();
    boolean contains(T data);
}
