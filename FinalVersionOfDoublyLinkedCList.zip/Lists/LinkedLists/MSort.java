/**
 * Write a description of class mSort here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class MSort
{

    /**
     * Constructor for objects of class MSort
     */
    public MSort() {

    }

    public static void main(String[] args){
        int[] nums = new int[]{6,5,2,8,4,1,9,7,3,0};

        //nums = sort(nums, 0, nums.length);

        System.out.print("[");
        for (int i = 0; i < nums.length; i++) {
            System.out.print(nums[i]);
            
            if (i < nums.length - 1) {
                System.out.print(", ");
            }
            else {
                System.out.println("]");
            }
        }
    }

    private static int partician(int[] array, int left, int right) {
        System.out.print("[");
        for (int i = 0; i < array.length; i++) {
            System.out.print(array[i]);
            
            if (i < array.length - 1) {
                System.out.print(", ");
            }
            else {
                System.out.println("]");
            }
        }
        
        if ((right - left) > 1) {
            int pivot = array[((right - left) / 2) + left];
            int i = left;
            int j = right;

            while (i <= j) {
                System.out.print("[");
                for (int a = 0; a < array.length; i++) {
                    System.out.print(array[a]);
                    
                    if (a < array.length - 1) {
                        System.out.print(", ");
                    }
                    else {
                        System.out.println("]");
                    }
                }
                
                while (array[i] < array[pivot]) {
                    i++;
                }

                while (array[j] > array[pivot]) {
                    j--;
                }

                if (array[i] < array[pivot] && array[j] > array[pivot]) {
                    int[] temp = array;
                    array[i] = temp[j];
                    array[j] = temp[i];

                    if (i == j) {
                        i++;
                        j--;
                    }
                }
            }
            partician(array, i, j);
        }

        return 1;
    }
}
