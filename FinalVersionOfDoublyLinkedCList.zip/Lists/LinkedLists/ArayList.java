/**
 * Creates a basic Array Based List.
 *
 * @author John Burns
 * @version 6/01/19
 */
public class ArayList<T> implements ArrayBasedList<T> {
    private int size;
    private Object[] array;
    
    /**
     * Constructor to create a new ArayList.
     */
    public ArayList() {
        size = 0;
        array = new Object[size];
    }
    
    /**
     * Adds data to the end of the list.
     * @param data The data to be entered into the ArayList.
     */
    public void add(T data) {
        changeArraySize(1, size);
        
        array[size - 1] = data;
    }
    
    /**
     * Allows for adds to not duplicate code.
     * @param howMuch How much the size should change.
     * @param indexChanged The value of the index that should be changed.
     */
    private void changeArraySize(int howMuch, int indexChanged) {
        size += howMuch;
        Object[] tempArray = new Object[array.length];
        for (int i = 0; i < tempArray.length; i++) {
            tempArray[i] = array[i];
        }
        array = new Object[size];
        for (int i = 0; i < tempArray.length; i++) {
            if (i < indexChanged) {
                array[i] = tempArray[i];
            }
            else {
                array[i + 1] = tempArray[i];
            }
        }
    }
    
    /**
     * adds data to the beginning of the list.
     * @param data The data to add to the list.
     */
    public void addFirst(T data) {
        changeArraySize(1, 0);
        
        array[0] = data;
    }
    
    /**
     * adds data to the list and the given index.
     * @param index The index to insert the data to.
     * @param data The the data to insert into the list.
     */
    public void add(int index, T data) {
        changeArraySize(1, index);
        array[index] = data;
    }
    
    /**
     * sets the given index in the list to the given data.
     * @param data The data to set the data on the given node index.
     * @param index The index to which the data should be inserted into.
     */
    public void set(int index, T data) {
        if (size() > 0) {
            array[index] = data;
        }
        else {
            add(0, data);
        }
    }
    
    /**
     * gets the data at the given index.
     * @index The location in the list to retrieve data from.
     */
    public T get(int index) {
        return (T)array[index];
    }
    
    /**
     * removes the data and location of the given index.
     * @index The place in the list to remove.
     */
    public void delete(int index) {
        if (size > 0) {
            for (int i = index; i < array.length - 1; i++) {
                array[i] = array[i + 1];
            }
            
            Object[] newArray = new Object[array.length - 1];
            for (int i = 0; i < array.length - 1; i++) {
                newArray[i] = array[i];
            }
            
            array = newArray;
            size--;
        }
    }
    
    /**
     * deletes the data and location at the beginning of the list.
     */
    public void deleteFirst() {
        if (size > 0) {
            delete(0);
        }
    }
    
    /**
     * deletes the data and location at the end of the list.
     */
    public void deleteLast() {
        if (size > 0) {
            Object[] newArray = new Object[array.length - 1];
            for (int i = 0; i < array.length - 1; i++) {
                newArray[i] = array[i];
            }
            array = newArray;
            size--;
        }
    }
    
    /**
     * gives the size of the ArrayList.
     * @return size The number of items currently in the ArrayList.
     */
    public int size() {
        return size;
    }
    
    /**
     * removes all data and locations from the arrayList.
     */
    public void clear() {
        size = 0;
        array = new Object[size];
    }
    
    /**
     * checks the entire list for the data given.
     * @param data The data to search for.
     * @return The answer to the question.
     */
    public boolean contains(T data) {
        boolean found = false;
        int index = 0;
        while (!found && index < array.length) {
            if (array[index].equals(data)) {
                found = true;
            }
            else {
                index++;
            }            
        }
        
        return found;
    }
    
    /**
     * Prints a readable version of the ArrayList.
     * @return The ArrayList in String form.
     */
    @Override
    public String toString() {
        String returnStr = "[";
        
        for (int i = 0; i < array.length; i++) {
            
            returnStr += (T)array[i];
            if (i < array.length - 1) {
                returnStr += ", ";
            }
            else {
                returnStr += "]";
            }
        }
        
        if (size() == 0) {
            returnStr += "]";
        }
        
        return returnStr;
    }
}
