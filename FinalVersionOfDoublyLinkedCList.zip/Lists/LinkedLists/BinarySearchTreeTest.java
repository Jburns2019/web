

import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * The test class BinarySearchTreeTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class BinarySearchTreeTest
{
    private BinarySearchTree binarySe1;

    /**
     * Default constructor for test class BinarySearchTreeTest
     */
    public BinarySearchTreeTest()
    {
    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @Before
    public void setUp()
    {
        binarySe1 = new BinarySearchTree(0);
        binarySe1.add(-5);
        binarySe1.add(5);
        binarySe1.add(-8);
        binarySe1.add(-3);
        binarySe1.add(3);
        binarySe1.add(8);
        binarySe1.add(-9);
        binarySe1.add(-7);
        binarySe1.add(-4);
        binarySe1.add(-2);
        binarySe1.add(2);
        binarySe1.add(7);
        binarySe1.add(9);
        binarySe1.add(-6);
        binarySe1.add(6);
        binarySe1.add(-1);
        binarySe1.add(1);
        binarySe1.add(4);
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @After
    public void tearDown() {
    }

    @Test
    public void inOrderTraversal()
    {
        assertEquals(new String("[-9, -8, -7, -6, -5, -4, -3, -2, -1, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9]"), binarySe1.toString());
    }
    
    @Test
    public void preOrderTraversal()
    {
        assertEquals(new String("[0, -5, -8, -9, -7, -6, -3, -4, -2, -1, 5, 3, 2, 1, 4, 8, 7, 6, 9]"), binarySe1.toString2());
    }

    @Test
    public void postTraversal()
    {
        assertEquals(new String("[-9, -6, -7, -8, -4, -1, -2, -3, -5, 1, 2, 4, 3, 6, 7, 9, 8, 5, 0]"), binarySe1.toString3());
    }

    @Test
    public void clear()
    {
        binarySe1.clear();
        assertEquals(null, binarySe1.first());
        assertEquals(null, binarySe1.last());
        assertEquals(new String("[]"), binarySe1.toString());
        assertEquals(new String("[]"), binarySe1.toString2());
        assertEquals(new String("[]"), binarySe1.toString3());
        assertEquals(0, binarySe1.size());
    }

    @Test
    public void first()
    {
        assertEquals(new Integer(-9), binarySe1.first());
    }

    @Test
    public void last()
    {
        assertEquals(new Integer(9), binarySe1.last());
    }

    @Test
    public void isEmpty()
    {
        assertEquals(false, binarySe1.isEmpty());
    }

    @Test
    public void size()
    {
        assertEquals(19, binarySe1.size());
    }
}








