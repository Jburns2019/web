import java.util.Iterator;
/**
 * A class that enables the creation of Doubly Linked Circular Lists.
 * 
 * @author John Burns
 * @version 05/24/19
 */
public class DoubleyLinkedList<T> implements DLinkedList<T>, Iterable<T> {
    private Node<T> nodeHead;
    private int endNodePos = -1;

    /**
     * A private internal class that handles the elements of the list.
     */
    private static class Node<T> {
        private T data;
        private Node<T> next;
        private Node<T> prev;

        /**
         * Create a new node with current data.
         * @param data The data the the current element should start with.
         */
        public Node(T data) {
            this.data = data;
            this.next = this;
            this.prev = this;
        }

        /**
         * gets the next element.
         * @return next The next element that the current element is 
         * pointing to.
         */
        public Node<T> getNext() {
            return next;
        }

        /**
         * gets the preivous element.
         * @return prev The previous element that the current element is 
         * pointing to.
         */
        public Node<T> getPrev() {
            return prev;
        }

        /**
         * gets the data of the current element.
         * @return data The data of the current element.
         */
        public T getData() {
            return data;
        }

        /**
         * sets the next element.
         * @param next The next element to point to.
         */
        public void setNext(Node<T> next) {
            this.next = next;
        }

        /**
         * sets the previous element.
         * @param prev The previous element to point to.
         */
        public void setPrev(Node<T> prev) {
            this.prev = prev;
        }

        /**
         * sets the data of the current element.
         * @param data The data to be changed.
         */
        public void setData(T data) {
            this.data = data;
        }
    }

    /**
     * creates a new list with it's first element empty.
     */
    public DoubleyLinkedList() {
        nodeHead = new Node(null);
        endNodePos++;
    }
    
    /**
     * creates a new list with it's first element filled.
     * @param data The data for the first element for the list.
     */
    public DoubleyLinkedList(T data) {
        nodeHead = new Node(data);
        endNodePos++;
    }

    public Iterator<T> iterator() {
        return new Iterator() {
            Node<T> eNode = nodeHead;
            int index = 0;
            boolean removed = false;

            /**
             * Checks to see if there is another element after the current
             * element.
             * @return The answer to the question.
             */
            public boolean hasNext() {
                boolean check = false;
                if (eNode.getNext() != nodeHead || removed) {
                    check = true;
                    if (index > 0 && !removed) {
                        eNode = eNode.getNext();
                    }
                    index++;
                    removed = false;
                }
                return check;
            }

            /**
             * Retrieve the current element's data.
             * @return The iterator's current element's data.
             */
            public T next() {
                return eNode.getData();
            }

            /**
             * iteratorable safe removal. Allows for an element to be removed while
             * going over the list of items.
             */
            public void remove() {
                eNode = eNode.getNext();
                delete(index - 1);
                removed = true;
            }
        };
    }

    /**
     * sets the data held in the element in the list at the given index to
     * the value of the data given.
     * @param index The position of the element in the list that will be 
     * changed.
     * @param data The data that will be changed.
     */
    public void set(int index, T data) {
        index = checkIndex(index);

        Node<T> eNode = nodeHead;
        if (index == 0) {//requesting nodeHead.
        }
        else if (index == endNodePos) {//requesting node at end.
            eNode = nodeHead.getPrev();
        }
        else {
            for (int i = 0; i < index; i++) {
                eNode = eNode.getNext();
            }
        }

        eNode.setData(data);
    }

    /**
     * A private method to reduce runtime cost of index number larger than 
     * the size of the list or index numbers smaller than 0.
     * @param index The index to be checked.
     */
    private int checkIndex(int index) {
        while (index > endNodePos) {
            if (endNodePos != 0) {
                index %= endNodePos;
            }
            else {
                index = 0;
            }
        }

        while (index < 0) {
            if (endNodePos != 0) {
                index %= endNodePos;
                index = 0 - index;
            }
            else {
                index = 0;
            }
        }

        return index;
    }

    /**
     * adds an element containing the data at the beginning of the list.
     * @param data The data to be inserted at the beginning of the list.
     */
    public void addFirst(T data) {
        if (nodeHead.prev.data != null) {
            //shift nodeHead over 1.
            Node<T> oldNodeHead = new Node(nodeHead.getData());
            endNodePos++;
            oldNodeHead.setPrev(nodeHead);
            if (endNodePos > 1) {
                oldNodeHead.setNext(nodeHead.getNext());
            }
            else {
                oldNodeHead.setNext(nodeHead);
            }

            Node<T> eNode = nodeHead.getPrev();
            eNode.setPrev(nodeHead.getPrev().getPrev());

            //create new nodeHead.
            nodeHead = new Node(data);
            nodeHead.setNext(oldNodeHead);
            nodeHead.setPrev(eNode);

            if (endNodePos == 1) {
                eNode.setPrev(oldNodeHead);
            }
            eNode.setNext(nodeHead);
        }
        else {
            nodeHead.getPrev().setData(data);
        }
    }

    /**
     * adds an element containing the data to the end of the list.
     * @param data The data to be inserted at the end of the list.
     */
    public void add(T data) {
        if (nodeHead.prev.data != null) {
            Node<T> newNode = new Node(data);
            endNodePos++;

            Node<T> eNode = nodeHead.getPrev();
            eNode.setPrev(nodeHead.getPrev().getPrev());

            if (endNodePos == 2) {
                nodeHead.setNext(eNode);
            }

            nodeHead.setPrev(newNode);
            newNode.setNext(nodeHead);

            eNode.setNext(newNode);
            newNode.setPrev(eNode);
        }
        else {
            nodeHead.getPrev().setData(data);
        } 
    }

    /**
     * Adds an element with the given data at the given index.
     * @param index The position in the list to insert the element.
     * @param data The data you wish to assign to the element at the given
     * index.
     */
    public void add(int index, T data) {
        if (index <= 0) {
            addFirst(data);
        }
        else if (index > endNodePos) {
            add(data);
        }
        else {
            Node<T> newNode = new Node(data);
            endNodePos++;
            Node<T> eNode = nodeHead;
            for (int i = 0; i < index; i++) {
                eNode = eNode.getNext();
            }
            newNode.setPrev(eNode.getPrev());
            newNode.setNext(eNode);
            eNode.getPrev().setNext(newNode);
            eNode.setPrev(newNode);
        }
    }

    /**
     * deletes the element 
     */
    public void delete(int index) {
        index = checkIndex(index);

        if (index == 0) {
            deleteFirst();
        }
        else if (index == endNodePos) {
            deleteLast();
        }
        else {
            Node<T> eNode = nodeHead;
            for (int i = 0; i < index; i++) {
                eNode = eNode.getNext();
            }
            eNode.getPrev().setNext(eNode.getNext());
            eNode.getNext().setPrev(eNode.getPrev());
            endNodePos--;
        }
    }

    /**
     * deletes the first element of the list. If the list conains only one
     * element it calls clear().
     */
    public void deleteFirst() {
        if (endNodePos == 0) {
            clear();
        }
        else {
            nodeHead.setData(null);
            nodeHead.getNext().setPrev(nodeHead.getPrev());
            nodeHead.getPrev().setNext(nodeHead.getNext());
            nodeHead = nodeHead.getNext();
            endNodePos--;
        }
    }

    /**
     * deletes the last element of the list. If the list contains only one
     * element then it calls clear().
     */
    public void deleteLast() {
        if (endNodePos == 0) {
            clear();
        }
        else {
            Node<T> eNode = nodeHead.getPrev();
            eNode.getPrev().setNext(nodeHead);
            nodeHead.setPrev(eNode.getPrev());
            endNodePos--;
        }
    }

    /**
     * Retrieves the current size of the list.
     * @return size The size of the list.
     */
    public int size() {
        return endNodePos + 1;
    }

    /**
     * Clears the entire list of all data. This also removes all pointers
     * by setting the pointers of nodeHead to itself.
     */
    public void clear() {
        nodeHead.setData(null);
        nodeHead.setNext(nodeHead);
        nodeHead.setPrev(nodeHead);
        endNodePos = 0;
    }

    /**
     * Checks whether the list has an element that contains the data. 
     * Please be sure the data member's class overrides Objects 
     * .equals or it will return false for obvious reasons.
     * @param data the data to compare.
     * @return The answer to the question.
     */
    public boolean contains(T data) {
        boolean check = false;
        int i = 0;
        Node<T> eNode = nodeHead;
        if (nodeHead.getData().equals(data)) {
            check = true;
        }
        if (nodeHead.getPrev().getData().equals(data)) {
            check = true;
        }
        while (!check && i < endNodePos) {
            eNode = eNode.getNext();
            if (eNode.getData().equals(data)) {
                check = true;
            }
            i++;
        }
        return check;
    }

    /**
     * Retrieves the data held at the given index's location.
     * @param index The index of the node the data is located at.
     * @return The data held at the given index's location.
     */
    public T get(int index) {
        index = checkIndex(index);

        Node<T> eNode = nodeHead;
        if (index == 0) {//requesting nodeHead.
        }
        else if (index == endNodePos) {//requesting node at end.
            eNode = nodeHead.getPrev();
        }
        else {//requesting a node between nodeHead and endNode.
            for (int i = 0; i < index; i++) {
                eNode = eNode.getNext();
            }
        }

        return eNode.getData();
    }

    /**
     * Provides access to the first element's data.
     * @return The first element's data.
     */
    public T getFirst() {
        return nodeHead.getData();
    }   

    /**
     * Provides access to the last element's data.
     * @return The last element's data.
     */
    public T getLast() {
        return nodeHead.getPrev().getData();
    }

    /**
     * overides Object's toString method to allow the list to be printed.
     * @return The string representation of this class.
     */
    @Override
    public String toString() {
        String returnStr = "[";
        int i = 0;
        Node<T> eNode = nodeHead;

        returnStr += eNode.getData();
        if (endNodePos != 0) {
            returnStr += ", ";
        }
        for (int in = 0; in < endNodePos; in++) {
            eNode = eNode.getNext();
            returnStr += eNode.getData();
            if (in != endNodePos - 1) {
                returnStr += ", ";
            }
        }
        returnStr += "]";
        return returnStr;
    }
}
