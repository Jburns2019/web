import java.lang.*;
import java.util.*;
/**
 * This is the basic version of a Binary Search Tree. It does not contain any remove methods as it is beyond
 * my ability and this was a personal project to begin with. The main point was to prove that I could create code for
 * making in order pre order and post order traversals.
 *
 * @author John Burns
 * @version 5/28/19
 */
public class BinarySearchTree<T extends Comparable<? super T>> implements BST<T> {
    private static class Node<T extends Comparable<? super T>> {
        private Node left;
        private Node right;
        private Node prev;
        private T data;
        private boolean leftVisited;
        private boolean rightVisited;
        private boolean valueVisited;
        private int repeatCount = -1;

        private Node(T data) {
            this.data = data;
            left = null;
            right = null;
            repeatCount = 0;
        }

        private void flipLeftVisited() {
            leftVisited = !leftVisited;
        }

        private void flipRightVisited() {
            rightVisited = !rightVisited;
        }

        private void flipValueVisited() {
            valueVisited = !valueVisited;
        }

        private boolean hasVisitedLeft() {
            return leftVisited;
        }

        private boolean hasVisitedRight() {
            return rightVisited;
        }

        private boolean hasVisitedValue() {
            return valueVisited;
        }

        private Node getLeft() {
            return left;
        }

        private Node getRight() {
            return right;
        }

        private Node getPrev() {
            return prev;
        }

        private T getData() {
            return data;
        }

        private int getRepCnt() {
            return repeatCount;
        }

        private void incrRepCnt() {
            repeatCount++;
        }

        private void setLeft(Node left) {
            this.left = left;
        }

        private void setRight(Node right) {
            this.right = right;
        }

        private void setPrev(Node prev) {
            this.prev = prev;
        }

        private void setData(T data) {
            this.data = data;
        }
    }
    private int nodeCount = -1;
    private int layerCount = -1;
    private Node nodeHead;
    private Node begOfTreeNode;
    private Node endOfTreeNode;
    private String returnStr = "";
    private boolean hasTraversed = false;

    /**
     * Creates a BinarySearchTree with the root being null.
     */
    public BinarySearchTree() {
        nodeHead = new Node(null);
        endOfTreeNode = nodeHead;
        begOfTreeNode = nodeHead;
    }

    /**
     * Creates a BinarySearchTree with data attached to the root.
     * @param data The data the tree should start out with.
     */
    public BinarySearchTree(int data) {
        nodeHead = new Node(data);
        endOfTreeNode = nodeHead;
        begOfTreeNode = nodeHead;
        nodeCount++;
        layerCount++;
    }

    /**
     * Adds the given data to the tree in accordance with Comparable.
     * @param data the data that will be added to the tree.
     */
    public void add(T data) {
        boolean searching = true;
        Node node = nodeHead;
        int layer = 0;
        if (node.getData() == null) {
            nodeHead.setData(data);
            searching = false;
        }
        while (searching) {
            int val = data.compareTo((T)node.getData());
            boolean lessThan = (val < 0);
            boolean is = (val == 0);
            boolean greaterThan = (val > 0);
            
            if (lessThan) {
                if (node.getLeft() == null) {
                    Node newNode = new Node(data);
                    node.setLeft(newNode);
                    newNode.setPrev(node);
                    node.getLeft().setData(data);
                    searching = false;
                    node = newNode;
                }
                else {
                    node = node.getLeft();
                }
                layer++;
            }
            else if (is) {
                node.incrRepCnt();
                searching = false;
            }
            else if (greaterThan) {
                if (node.getRight() == null) {
                    Node newNode = new Node(data);
                    node.setRight(newNode);
                    newNode.setPrev(node);
                    node.getRight().setData(data);
                    searching = false;
                    node = newNode;
                }
                else {
                    node = node.getRight();
                }
                layer++;
            }
        }
        if (layer >= layerCount) {
            layerCount = layer;
        }
        
        if (node.getData().compareTo(endOfTreeNode.getData()) > 0) {
            endOfTreeNode = node;
        }
        
        if (node.getData().compareTo(begOfTreeNode.getData()) < 0) {
            begOfTreeNode = node;
        }

        nodeCount++;
    }

    /**
     * Finds the total size of the tree.
     * @return size The size of the tree.
     */
    public int size() {
        return nodeCount + 1;
    }

    /**
     * Empties the tree so that only the root exists, but is set to null.
     */
    public void clear() {
        nodeHead = new Node(null);
        endOfTreeNode = nodeHead;
        begOfTreeNode = nodeHead;

        nodeCount = -1;
        layerCount = -1;
        returnStr = "";
        boolean hasTraversed = false;
    }

    /**
     * checks to see if the toString version contains the data.
     * @param data The data to check for.
     * @return The answer to the question.
     */
    public boolean contains(T data) {
        return toString().contains("" + data);
    }

    /**
     * gets the first (in order) item of the tree.
     * @return The data from the first (in order) place.
     */
    public T first() {
        return (T)begOfTreeNode.getData();
    }

    /**
     * checks to see if there is any data.
     * @return The answer to the question.
     */
    public boolean isEmpty() {
        return size() == 0;
    }

    /**
     * @return The data from the last (in order) place.
     */
    public T last() {
        return (T)endOfTreeNode.getData();
    }

    /**
     * @return The number of layers the tree has.
     */
    public int getLayerCount() {
        return layerCount + 1;
    }

    /**
     * The typical representation of the tree.
     * @return The inorder traversal of the tree.
     */
    public String toString() {
        returnStr = "[";
        if (nodeHead.getData() != null) {
            int index = 0;
            if (!hasTraversed) {
                Node endNode = inOrderTraversal(nodeHead, index);
            }
            else {
                Node endNode = inOrderTraversalT(nodeHead, index);
            }
        }
        else {
            returnStr += "]";
        }
        hasTraversed = !hasTraversed;
        return returnStr;
    }

    /**
     * Gathers the in order traversal as long as the tree hasn't been traversed already.
     */
    private Node inOrderTraversalT(Node startNode, int index) {
        Node eNode = startNode;
        if (index <= nodeCount) {
            if (eNode.getLeft() != null && eNode.hasVisitedLeft()) {
                eNode.flipLeftVisited();
                eNode = eNode.getLeft();
                index--;
            }
            else if (eNode.getLeft() == null || !eNode.hasVisitedLeft()) {
                if (!eNode.hasVisitedValue()) {
                    if (eNode.getRight() != null && eNode.hasVisitedRight()) {
                        eNode.flipRightVisited();
                        eNode = eNode.getRight();
                        index--;
                    }
                    else if (eNode.getRight() == null || !eNode.hasVisitedRight()) {
                        if (eNode.getPrev() != null) {
                            eNode = eNode.getPrev();
                            index--;
                        }
                    }

                }
                else {
                    returnStr += eNode.getData();
                    if (index < nodeCount) {
                        returnStr += ", ";
                    }
                    else if (index == nodeCount) {
                        returnStr += "]";
                    }
                    eNode.flipValueVisited();
                }
            }
            index++;
            inOrderTraversalT(eNode, index);
        }
        return eNode;
    }

    /**
     * Performs the inordertraversal if the tree has already been traversed.
     */
    private Node inOrderTraversal(Node startNode, int index) {
        Node eNode = startNode;
        if (index <= nodeCount) {
            if (!hasTraversed) {
                if (eNode.getLeft() != null && !eNode.hasVisitedLeft()) {
                    eNode.flipLeftVisited();
                    eNode = eNode.getLeft();
                    index--;
                }
                else if (eNode.getLeft() == null || eNode.hasVisitedLeft()) {
                    if (eNode.hasVisitedValue()) {
                        if (eNode.getRight() != null && !eNode.hasVisitedRight()) {
                            eNode.flipRightVisited();
                            eNode = eNode.getRight();
                            index--;
                        }
                        else if (eNode.getRight() == null || eNode.hasVisitedRight()) {
                            if (eNode.getPrev() != null) {
                                eNode = eNode.getPrev();
                                index--;
                            }
                        }
                    }
                    else {
                        returnStr += eNode.getData();
                        if (index < nodeCount) {
                            returnStr += ", ";
                        }
                        else if (index == nodeCount) {
                            returnStr += "]";
                        }
                        eNode.flipValueVisited();
                    }
                }
            }
            index++;
            inOrderTraversal(eNode, index);
        }
        return eNode;
    }

    /**
     * @return The preOrder traversal of the tree.
     */
    public String toString2() {
        returnStr = "[";

        if (nodeHead.getData() != null) {
            int index = 0;
            if (!hasTraversed) {
                Node endNode = preOrderTraversal(nodeHead, index);
            }
            else {
                Node endNode = preOrderTraversalT(nodeHead, index);
            }
        }
        else {
            returnStr += "]";
        }

        hasTraversed = !hasTraversed;
        return returnStr;
    }

    /**
     * Performs the preordertraversal if the tree hasn't already been traversed.
     */
    private Node preOrderTraversalT(Node startNode, int index) {
        Node eNode = startNode;
        if (index <= nodeCount) {
            if (eNode.hasVisitedValue()) {
                returnStr += eNode.getData();
                eNode.flipValueVisited();
                if (index < nodeCount) {
                    returnStr += ", ";
                    System.out.println(index);
                }
                else if (index == nodeCount) {
                    returnStr += "]";
                }
            }
            else {
                if (eNode.getLeft() != null && eNode.hasVisitedLeft()) {
                    eNode.flipLeftVisited();
                    eNode = eNode.getLeft();
                    index--;
                }
                else if (eNode.getLeft() == null || !eNode.hasVisitedLeft()) {
                    if (eNode.getRight() != null && eNode.hasVisitedRight()) {
                        eNode.flipRightVisited();
                        eNode = eNode.getRight();
                        index--;
                    }
                    else if (eNode.getRight() == null || !eNode.hasVisitedRight()) {
                        if (eNode.getPrev() != null) {
                            eNode = eNode.getPrev();
                            index--;
                        }
                    }
                }
            }
            index++;
            preOrderTraversalT(eNode, index);
        }
        return eNode;
    }

    /**
     * Performs the preordertraversal if the tree has already been traversed.
     */
    private Node preOrderTraversal(Node startNode, int index) {
        Node eNode = startNode;
        if (index <= nodeCount) {
            if (!eNode.hasVisitedValue()) {
                returnStr += eNode.getData();
                eNode.flipValueVisited();
                if (index < nodeCount) {
                    returnStr += ", ";
                }
                else if (index == nodeCount) {
                    returnStr += "]";
                }
            }
            else {
                if (eNode.getLeft() != null && !eNode.hasVisitedLeft()) {
                    eNode.flipLeftVisited();
                    eNode = eNode.getLeft();
                    index--;
                }
                else if (eNode.getLeft() == null || eNode.hasVisitedLeft()) {
                    if (eNode.getRight() != null && !eNode.hasVisitedRight()) {
                        eNode.flipRightVisited();
                        eNode = eNode.getRight();
                        index--;
                    }
                    else if (eNode.getRight() == null || eNode.hasVisitedRight()) {
                        if (eNode.getPrev() != null) {
                            eNode = eNode.getPrev();
                            index--;
                        }
                    }
                }
            }
            index++;
            preOrderTraversal(eNode, index);
        }
        return eNode;
    }

    /**
     * @return The postOrderTraversal of the tree.
     */
    public String toString3() {
        returnStr = "[";

        if (nodeHead.getData() != null) {
            int index = 0;
            if (!hasTraversed) {
                Node endNode = postOrderTraversal(nodeHead, index);
            }
            else {
                Node endNode = postOrderTraversalT(nodeHead, index);
            }
        }
        else {
            returnStr += "]";
        }

        hasTraversed = !hasTraversed;
        return returnStr;
    }

    /**
     * Performs the postordertraversal if the tree hasn't already been traversed.
     */
    private Node postOrderTraversalT(Node startNode, int index) {
        Node eNode = startNode;
        if (index <= nodeCount) {
            if (eNode.getLeft() != null && eNode.hasVisitedLeft()) {
                eNode.flipLeftVisited();
                eNode = eNode.getLeft();
                index--;
            }
            else if (eNode.getLeft() == null || !eNode.hasVisitedLeft()) {
                if (eNode.getRight() != null && eNode.hasVisitedRight()) {
                    eNode.flipRightVisited();
                    eNode = eNode.getRight();
                    index--;
                }
                else if (eNode.getRight() == null || !eNode.hasVisitedRight()) {
                    if (!eNode.hasVisitedValue()) {
                        returnStr += eNode.getData();
                        if (index < nodeCount) {
                            returnStr += ", ";
                        }
                        else if (index == nodeCount) {
                            returnStr += "]";
                        }
                        index++;
                    }

                    if (eNode.getPrev() != null) {
                        eNode = eNode.getPrev();
                        index--;
                    }
                }
            }
            index++;
            postOrderTraversalT(eNode, index);
        }
        return eNode;
    }

    /**
     * Performs the postordertraversal if the tree has already been traversed.
     */
    private Node postOrderTraversal(Node startNode, int index) {
        Node eNode = startNode;
        if (index <= nodeCount) {
            if (eNode.getLeft() != null && !eNode.hasVisitedLeft()) {
                eNode.flipLeftVisited();
                eNode = eNode.getLeft();
                index--;
            }
            else if (eNode.getLeft() == null || eNode.hasVisitedLeft()) {
                if (eNode.getRight() != null && !eNode.hasVisitedRight()) {
                    eNode.flipRightVisited();
                    eNode = eNode.getRight();
                    index--;
                }
                else if (eNode.getRight() == null || eNode.hasVisitedRight()) {
                    if (!eNode.hasVisitedValue()) {
                        returnStr += eNode.getData();
                        if (index < nodeCount) {
                            returnStr += ", ";
                        }
                        else if (index == nodeCount) {
                            returnStr += "]";
                        }
                        index++;
                    }

                    if (eNode.getPrev() != null) {
                        eNode = eNode.getPrev();
                        index--;
                    }
                }
            }
            index++;
            postOrderTraversal(eNode, index);
        }
        return eNode;
    }
}
