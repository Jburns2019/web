
/**
 * Write a description of interface Drawablw here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public interface Drawable
{
    default void draw() {
        System.out.print("Drawing...");
    }
}
