
/**
 * Write a description of class Circle here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Circle extends Shape
{
    private double radius;
    private String name;

    /**
     * Constructor for objects of class Circle
     */
    public Circle(double radius)
    {
        this.radius = radius;
        name = "Circle";
    }

    public double getRadius() {
        return radius;
    }
    
    public int getArea() {
        return (int)(Math.PI * radius * radius);
    }
    
    public int getParameter() {
        return (int)(Math.PI * 2.0 * radius);
    }
    
    public String getName() {
        return name;
    }
}
