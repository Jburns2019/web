import java.util.List;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.function.BinaryOperator;
/**
 * Write a description of class testClass here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class testClass
{
    private static List<Shape> list;

    /**
     * Constructor for objects of class testClass
     */
    public testClass()
    {
    }

    public static void main(String[] args){
        list = new ArrayList<>();
        list.add(new Rectangle((int)Math.PI, 1));
        list.add(new Circle(1.0));
        list.add(new Square(3, 3));
       
       
       Collections.sort(list);
        
       list.stream().forEach(System.out::println);
       list.stream().forEach(item -> item.draw());
            
       //testing various ideas.
       Shape[] shapes = list.stream().sorted().toArray(Shape[]::new);
       for (int i = 0; i < shapes.length; i++) {
           System.out.println(shapes[i]);
       }
        
       
       
       //That one took a little bit...
        Comparator<Shape> a = new Comparator<Shape>() {
            public int compare(Shape s1, Shape s2) {
                return s1.getParameter() - s2.getParameter();
            }
        };
        
        
        Collections.sort(list, a);
        System.out.println(list);
    }
}
