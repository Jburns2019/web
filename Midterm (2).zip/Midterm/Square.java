
/**
 * Write a description of class Square here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Square extends Rectangle
{
    private String name;
    private int width;
    private int height;

    /**
     * Constructor for objects of class Square
     */
    public Square(int width, int height) {
        super(width, height);
        this.width = width;
        this.height = height;
        name = "Square";
    }
    
    @Override
    public String getName() {
        return name;
    }
}
