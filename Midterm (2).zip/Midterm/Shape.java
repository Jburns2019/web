/**
 * Write a description of class Shape here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public abstract class Shape implements Comparable<Shape>, Drawable
{
    /**
     * Constructor for objects of class Shape
     */
    public Shape() {    
    }

    public int compareTo(Shape shape) {
        int returnVal = 0;
        
        if (this == shape) {
            returnVal = 0;
        }
        returnVal = this.getArea() - shape.getArea();
        return returnVal;
    }
    
    public abstract int getArea();
    
    public abstract String getName();
    
    public abstract int getParameter();
    
    public String toString() {
        return "name : " + getName() + ", area : " + getArea() + 
                ", parameter: " + getParameter() + ".";
    }
}
