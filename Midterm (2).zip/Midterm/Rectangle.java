
/**
 * Write a description of class Rectangle here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Rectangle extends Shape
{
    private int height;
    private int width;
    private String name;

    /**
     * Constructor for objects of class Rectangle
     */
    public Rectangle(int width, int height) {
        this.height = height;
        this.width = width;
        this.name = "Rectangle";
    }

    public int getArea() {
        return getHeight() * getWidth();
    }
    
    public String getName() {
        return name;
    }
    
    public int getParameter() {
        return (2 * getHeight()) + (2 * getWidth());
    }
    
    public int getHeight() {
        return height;
    }
    
    public int getWidth() {
        return width;
    }
}
