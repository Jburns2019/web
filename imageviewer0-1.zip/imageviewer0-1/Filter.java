
/**
 * Abstract class Filter - write a description of the class here
 *
 * @author (your name here)
 * @version (version number or date here)
 */
public abstract class Filter
{
    private String name;
    
    /**
     * Create a new filter with a given name.
     * @param name The name of the filter.
     */
    public Filter(String name) {
        this.name = name;
    }
    
    /**
     * Return the name of this filter.
     * @return name The name of this filter.
     */
    public String getName() {
        return name;
    }
    
    /**
     * Apply this filter to an image.
     * @param image The image to be changed by this filter.
     */
    public void apply(OFImage image) {
        implementFilter(image);
    }
    
    public abstract void implementFilter(OFImage image);
}
