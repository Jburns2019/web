import java.awt.Color;
/**
 * Write a description of class ThresholdFilter here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class ThresholdFilter extends Filter
{
    /**
     * Constructor for objects of class ThresholdFilter
     */
    public ThresholdFilter(String name) {
        super(name);
    }
    
    /**
     * Apply this filter to an image.
     * @param image The image to be changed by this filter.
     */
    public void implementFilter(OFImage image) {
        for (int xVal = 0; xVal < image.getWidth(); xVal++) {
            for (int yVal = 0; yVal < image.getHeight(); yVal++) {
                Color pixel = image.getPixel(xVal, yVal);
                int brightness = (pixel.getRed() + pixel.getBlue() + pixel.getGreen());
                if (brightness <= 85) {
                    image.setPixel(xVal, yVal, Color.BLACK);
                }
                else if (brightness <= 170) {
                    image.setPixel(xVal, yVal, Color.GRAY);
                }
                else {
                    image.setPixel(xVal, yVal, Color.WHITE);
                }
            }
        }
    }
}
