
/**
 * Write a description of class MirrorFilter here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class MirrorFilter extends Filter
{
    /**
     * Constructor for objects of class DarkerFilter
     * @param name The name of the filter.
     */
    public MirrorFilter(String name) {
        super(name);
    }
    
    /**
     * Apply this filter to an image.
     * @param image The image to be changed by this filter.
     */
    public void implementFilter(OFImage image) {
        for (int xVal = 0; xVal < image.getWidth(); xVal++) {
            for (int yVal = 0; yVal < image.getHeight(); yVal++) {
                int newx = image.getWidth() - 1 - xVal;
                if (xVal < (image.getWidth() - 1) / 2) {
                    image.setPixel(xVal, yVal, image.getPixel(newx, yVal));
                }
                else {
                    image.setPixel(xVal, yVal, ImageViewer.getPriorImage().getPixel(newx, yVal));
                }
            }
        }
    }
}
