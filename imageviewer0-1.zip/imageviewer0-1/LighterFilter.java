
/**
 * Write a description of class LighterFilter here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class LighterFilter extends Filter
{
    /**
     * Constructor for objects of class LighterFilter
     */
    public LighterFilter(String name) {
        super(name);
    }
    
    /**
     * Apply this filter to an image.
     * @param image The image to be changed by this filter.
     */
    public void implementFilter(OFImage image) {
        for (int xVal = 0; xVal < image.getWidth(); xVal++) {
            for (int yVal = 0; yVal < image.getHeight(); yVal++) {
                image.setPixel(xVal, yVal, image.getPixel(xVal, yVal).brighter());
            }
        }
    }
}
