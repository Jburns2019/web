import java.awt.Color;
/**
 * Write a description of class InvertFilter here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class InvertFilter extends Filter
{
    /**
     * Constructor for objects of class DarkerFilter
     * @param name The name of the filter.
     */
    public InvertFilter(String name) {
        super(name);
    }
    
    /**
     * Apply this filter to an image.
     * @param image The image to be changed by this filter.
     */
    public void implementFilter(OFImage image) {
        for (int xVal = 0; xVal < image.getWidth(); xVal++) {
            for (int yVal = 0; yVal < image.getHeight(); yVal++) {
                Color pixCol = image.getPixel(xVal, yVal);
                int redColor = 255 - pixCol.getRed();
                int greenColor = 255 - pixCol.getGreen();
                int blueColor = 255 - pixCol.getBlue();
                image.setPixel(xVal, yVal, new Color(redColor, greenColor, blueColor));
            }
        }
    }
}
