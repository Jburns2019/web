import java.awt.Color;
/**
 * Write a description of class SmoothFilter here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class SmoothFilter extends Filter
{
    /**
     * Constructor for objects of class DarkerFilter
     * @param name The name of the filter.
     */
    public SmoothFilter(String name) {
        super(name);
    }
    
    /**
     * Apply this filter to an image.
     * @param image The image to be changed by this filter.
     */
    public void implementFilter(OFImage image) {
       int maxW = image.getWidth();
       int maxH = image.getHeight();
       OFImage priorImage = ImageViewer.getPriorImage();
       
       for (int xVal = 0; xVal < image.getWidth(); xVal++) {
            for (int yVal = 0; yVal < image.getHeight(); yVal++) {         
                if (xVal > 0 && xVal < (maxW - 1) && yVal > 0 && yVal < (maxH - 1)) { 
                    int redVal = 0;
                    int greenVal = 0;
                    int blueVal = 0;
                    for (int w = -1; w <= 1; w++) {
                        for (int h = -1; h <= 1; h++) {
                            redVal += priorImage.getPixel(xVal + w, yVal + h).getRed();
                            greenVal += priorImage.getPixel(xVal + w, yVal + h).getGreen();
                            blueVal += priorImage.getPixel(xVal + w, yVal + h).getBlue();
                        }
                    }
                    redVal /= 9;
                    greenVal /= 9;
                    blueVal /= 9;
            
                    image.setPixel(xVal, yVal, new Color(redVal, greenVal, blueVal));
                }
            }
        }
    }
}
