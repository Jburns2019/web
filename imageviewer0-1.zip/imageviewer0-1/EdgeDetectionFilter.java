import java.awt.Color;
import java.util.Arrays;
/**
 * Write a description of class EdgeDetectionFilter here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class EdgeDetectionFilter extends Filter
{
    /**
     * Constructor for objects of class DarkerFilter
     * @param name The name of the filter.
     */
    public EdgeDetectionFilter(String name) {
        super(name);
    }
    
    /**
     * Apply this filter to an image.
     * @param image The image to be changed by this filter.
     */
    public void implementFilter(OFImage image) {
        
        int maxW = image.getWidth();
        int maxH = image.getHeight();
        OFImage priorImage = ImageViewer.getPriorImage();
        
        for (int xVal = 0; xVal < image.getWidth(); xVal++) {
            for (int yVal = 0; yVal < image.getHeight(); yVal++) {        
                if (xVal > 0 && xVal < (maxW - 1) && yVal > 0 && yVal < (maxH - 1)) {
                    int[] redVals = new int[9];
                    int[] greenVals = new int[9];
                    int[] blueVals = new int[9];
                    int index = 0;
                    for (int w = -1; w <= 1; w++) {
                        for (int h = -1; h <= 1; h++) {
                            redVals[index] = priorImage.getPixel(xVal + w, yVal + h).getRed();
                            greenVals[index] = priorImage.getPixel(xVal + w, yVal + h).getGreen();
                            blueVals[index] = priorImage.getPixel(xVal + w, yVal + h).getBlue();
                            index++;
                        }
                    }
                    Arrays.sort(redVals);
                    Arrays.sort(greenVals);
                    Arrays.sort(blueVals);
            
                    image.setPixel(xVal, yVal, new Color(redVals[8] - redVals[0], 
                                                greenVals[8] - greenVals[0], 
                                                blueVals[8] - blueVals[0]));
        }
    }
}
    }
}
