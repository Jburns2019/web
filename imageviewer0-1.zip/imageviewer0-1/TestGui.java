import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
/**
 * Write a description of class TestGui here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class TestGui
{
    private JFrame frame;
    
    public TestGui() {
        makeFrame();
    }
    
    private void makeFrame() {
        frame  = new JFrame("My Window");
        Container contentPane = frame.getContentPane();
        
        JPanel panel  = new JPanel();
        contentPane.add(panel);
        
        JLabel label = new JLabel("This is some random text.");
        panel.add(label);
        
        JButton button = new JButton("Click Me");
        panel.add(button);
        
        JTextField textBox = new JTextField(15);
        panel.add(textBox);
        
        button.addActionListener(e -> {
            String name = JOptionPane.showInputDialog(null, "Name Please?");
            textBox.setText(name);
        });
        
        frame.pack();
        frame.setVisible(true);
    }
}
