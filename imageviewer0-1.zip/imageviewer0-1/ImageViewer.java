import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import javax.swing.*;
import javax.swing.border.*;

import java.io.File;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Stack;
import java.util.HashMap;
import java.util.Set;
import java.util.LinkedList;
import java.util.Timer;
import java.util.TimerTask;
import java.util.function.BinaryOperator;
import java.util.function.UnaryOperator;

/**
 * ImageViewer is the main class of the image viewer application. It builds
 * and displays the application GUI and initialises all other components.
 * 
 * To start the application, create an object of this class.
 * 
 * @author Michael Kölling and David J. Barnes.
 * @version 0.1
 */
public class ImageViewer extends JFrame
{
    private static final String VERSION = "Version 4.0";
    private static JFileChooser fileChooser = new JFileChooser(System.getProperty("user.dir"));
    
    
    private JLabel filenameLabel;
    private JLabel statusLabel;
    private JButton smallerButton;
    private JButton largerButton;
    private static OFImage priorImage;
    private JScrollPane scrollPane;
    private JTabbedPane tabbedPane;
    private JPanel contentPane;
    private JPanel panel;
    private JSlider slider;
    //Current editing color.
    private Color currentColor;
    private Graphics2D g;
    
    int currentNumber;
    int widthOStroke;
    int heightOStroke;
    int indexCheck = 0;
    
    private ArrayList<JMenuItem> menuItems;
    private List<Filter> filters;
    private static Stack<OFImage> pastImages;
    private static Stack<OFImage> undoneImages;
    private ArrayList<Integer> row;
    private ArrayList<Integer> col;
    private HashMap<JMenuItem, String> paramStrings;
    private ArrayList<ImagePanel> allImagePanels;
    private ArrayList<OFImage> allImagePanelImages;
    private ArrayList<OFImage> allOriginalPanelImages;
    private Stack<Integer> checker;
    
    
    /**
     * Create an ImageViewer show it on screen.
     */
    public ImageViewer()
    {
        super("ImageViewer");
        filters = createFilters();
        pastImages = new Stack<>();
        undoneImages = new Stack<>();
        checker = new Stack<>();
        allImagePanels = new ArrayList<>();
        allImagePanelImages = new ArrayList<>();
        allOriginalPanelImages = new ArrayList<>();
        menuItems = new ArrayList<>();
        paramStrings = new HashMap<>();
        row = new ArrayList<>();
        col = new ArrayList<>();
        tabbedPane = new JTabbedPane();
        makeFrame();
    }
    
    public static void main(String[] args) {
        ImageViewer newImageViewer = new ImageViewer();
    }
    
    // ---- swing stuff to build the frame and all its components ----
    
    /**
     * Create the Swing frame and its content.
     */
    private void makeFrame()
    {      
        //create container.
        contentPane = (JPanel)getContentPane();
        contentPane.setBorder(new EmptyBorder(12,12,12,12));
        
        makeMenuBar();
        
        //specify the layout manager.
        contentPane.setLayout(new BorderLayout(6, 6));
        
        //make a label.
        filenameLabel = new JLabel();
            contentPane.add(filenameLabel, BorderLayout.NORTH);
            
        //make an image holder.
        addPanel(new ImagePanel());
        
        // create a toolbar with buttons.
        contentPane.add(makeButtons(), BorderLayout.WEST);
        
        //make a second label.
        panel = new JPanel();
        statusLabel = new JLabel(VERSION);
        panel.add(statusLabel);
        slider = new JSlider(0, 50, 0);
        slider.addChangeListener(e -> slide());
        panel.add(slider);
            contentPane.add(panel, BorderLayout.SOUTH);
        
        // building is done - arange the components and show.
        showFilename(null);
        pack();
        
        Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
        setLocation(d.width/2 - getWidth()/2, d.height/2 - getHeight()/2);
        setVisible(true);
    }
    
    /**
     * Create the MenuBar.
     */
    private void makeMenuBar() {
        final int SHORTCUT_MASK = 
            Toolkit.getDefaultToolkit().getMenuShortcutKeyMask();
        
        JMenuBar menubar = new JMenuBar();
        setJMenuBar(menubar);
        
        JMenu menu = null;
        JMenuItem item = null;
                  
        String name;
        
        // create the File menu
        name = "File";
        menu = createMenu(name, menu, menubar);
        
        name = "Open";
        item = createMenuItem(name, item, menu);
        item.addActionListener(e -> openFile());
        menu.add(item);
        
        name = "Slide Show";
        item = createMenuItem(name, item, menu);
        item.addActionListener(e -> slideShow());
        menu.add(item);
        
        name = "Close";
        item = createMenuItem(name, item, menu);
        item.addActionListener(e -> close());
        menu.add(item);
        menu.addSeparator();
            
        name = "Quit";
        item = createMenuItem(name, item, menu);
        item.addActionListener(e -> quit());
        menu.add(item);
        
        name  = "Save";
        item = createMenuItem(name, item, menu);
        item.addActionListener(e -> saveFile());
        menu.add(item);
        
        name  = "View";
        // create the back Menu;
        menu = createMenu(name, menu, menubar);
        
        name = "SingleUndo";
        item = createMenuItem(name, item, menu);
        item.addActionListener(e -> undo());
        menu.add(item);
        
        name = "Multiple Undos";        
        final JMenuItem undoItem = createMenuItem(name, item, menu);
        undoItem.addMouseListener(new MouseAdapter() {
                public void mousePressed(MouseEvent e) {handleMouseClicked(e, undoItem); }
            });
        menu.add(undoItem);
        
        name = "Single Redo";
        item = createMenuItem(name, item, menu);
        item.addActionListener(e -> redo());
        menu.add(item);
        
        name = "Multiple Redos";
        final JMenuItem redoItem = createMenuItem(name, item, menu);
        redoItem.addMouseListener(new MouseAdapter() {
                public void mousePressed(MouseEvent e) {handleMouseClicked(e, redoItem); }
            });
        menu.add(redoItem);
        
        name = "Original";
        item = createMenuItem(name, item, menu);
        item.addActionListener(e -> getOriginal());
        menu.add(item);
            
        // create the Help menu
        name = "Help";
        menu = createMenu(name, menu, menubar);
        
        name  = "About";
        item = createMenuItem(name, item, menu);
        item.addActionListener(e -> about());
        menu.add(item);
        
        // create the Filter menu
        name = "Filter";
        menu = createMenu(name, menu, menubar);
        
        for (Filter filter : filters) {
            name = filter.getName();
            item = createMenuItem(name, item, menu);
            item.addActionListener(e -> applyFilter(filter));
            menu.add(item);
        }
        
        // Adjust orientation and size
        name = "Adjust";
        menu = createMenu(name, menu, menubar);
        
        Set<JMenuItem> keys = paramStrings.keySet();
        JMenuItem rotateMenu = keys.stream().filter(mI -> paramStrings.get(mI).equals("Adjust"))
                                        .findFirst().get();
        name = "Rotate";
        menu = new JMenu(name);
        paramStrings.put(menu, name);
        rotateMenu.add(menu);
        menuItems.add(menu);
        
        name = "Make Picture Smaller";
        item = createMenuItem(name, item, menu);
        item.addActionListener(e -> smallerButton());
        menu.add(item);
        
        name = "Make Picture Larger";
        item = createMenuItem(name, item, menu);
        item.addActionListener(e -> largerButton());
        menu.add(item);
        
        item = createMenuItem("90", item, menu);
        item.addActionListener(e -> rotate(Integer.parseInt("90")));
        menu.add(item);
        
        
        item = createMenuItem("180", item, menu);
        item.addActionListener(e -> rotate(Integer.parseInt("180")));
        menu.add(item);
        
        // edit brush size.
        name = "Brush";
        menu = createMenu(name, menu, menubar);
        
        name = "Increase Brush Size";
        item = createMenuItem(name, item, menu);
        item.addActionListener(e -> incrementBrushSize());
        menu.add(item);
        
        name = "Decrease Brush Size";
        item = createMenuItem(name, item, menu);
        item.addActionListener(e -> decrementBrushSize());
        menu.add(item);
        
        name = "Draw Lines";
        item = createMenuItem(name, item, menu);
        item.addActionListener(e -> draw());
        menu.add(item);
        
        for (JMenuItem menuItem : menuItems) {
            if (!(paramStrings.get(menuItem).equals("File") || 
                  paramStrings.get(menuItem).equals("Open") ||
                  paramStrings.get(menuItem).equals("Quit") ||
                  paramStrings.get(menuItem).equals("Slide Show"))) {
                menuItem.setEnabled(false);
            }
        }
    }
    
    private JMenu createMenu(String name, JMenu menu, JMenuBar menubar) {
        menu = new JMenu(name);
        paramStrings.put(menu, name);
        menubar.add(menu);
        menuItems.add(menu);
        return menu;
    }
    
    private JMenuItem createMenuItem(String name, JMenuItem item, JMenu menu) {
        item = new JMenuItem(name);
        paramStrings.put(item, name);
        menuItems.add(item);
        return item;
    }
    
    /**
     * Create the buttons for the toolbar.
     */
    private JPanel makeButtons() {
        JPanel toolbar = new JPanel();
        toolbar.setLayout(new GridLayout(0, 1));
        
        smallerButton = new JButton("Smaller");
            smallerButton.addActionListener(e -> smallerButton());
        toolbar.add(smallerButton);
        
        largerButton = new JButton("Larger");
            largerButton.addActionListener(e -> largerButton());
        toolbar.add(largerButton);
        
        enableButtons(false);
        
        JPanel flow = new JPanel();
        flow.add(toolbar);
        
        return flow;
    }
    // ---- implementation of menu functions ----
    
    /**
     * Open function: open a file chooser to select a new image file.
     */
    private void openFile() {
        fileChooser.setMultiSelectionEnabled(false);
        fileChooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
        int returnVal = fileChooser.showOpenDialog(this);
        if (allImagePanelImages.isEmpty()) {
           tabbedPane.remove(scrollPane);
        }
        
        if (returnVal != JFileChooser.APPROVE_OPTION) {
            return;
        }
        File selectedFile = fileChooser.getSelectedFile();
        
        if (selectedFile.getPath().endsWith(".png") ||
            selectedFile.getPath().endsWith(".jpg") ||
            selectedFile.getPath().endsWith(".gif")) {
            allImagePanelImages.add(ImageFileManager.loadImage(selectedFile));
            allOriginalPanelImages.add(ImageFileManager.loadImage(selectedFile));
        }
        else {
        }
        
        BoundedRangeModel myModel = new DefaultBoundedRangeModel() {
            public void setRangeProperties(int value,
                        int extent,
                        int min,
                        int max,
                        boolean adjusting) {
                super.setRangeProperties(value, extent, min, max, adjusting);
            }
        };
        myModel.setRangeProperties(indexCheck, indexCheck, 0, indexCheck, false);
        slider.setModel(myModel);
        
        slider.setMajorTickSpacing(indexCheck);
        slider.setMinorTickSpacing(1);
        slider.setPaintTicks(true);
        
        enableButtons(true);
        for (JMenuItem menuItem : menuItems) {
            menuItem.setEnabled(true);
        }
        
        if(allImagePanelImages.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                      "The file was not in a recognized image file format.",
                      "Image Load Error",
                      JOptionPane.ERROR_MESSAGE);
            enableButtons(false);
            for (JMenuItem menuItem : menuItems) {
            if (!(paramStrings.get(menuItem).equals("File") || 
                  paramStrings.get(menuItem).equals("Open") ||
                  paramStrings.get(menuItem).equals("Quit") ||
                  paramStrings.get(menuItem).equals("Slide Show"))) {
                menuItem.setEnabled(false);
            }
        }         
            return;
        }
        
        ImagePanel panel = new ImagePanel();
        
        setCurrentPanel(panel);
        
        allImagePanels.get(indexCheck).setImage(allImagePanelImages.get(indexCheck));
        tabbedPane.setSelectedIndex(indexCheck);
        slider.setValue(indexCheck);
        showFilename(selectedFile.getPath());
        allImagePanels.get(indexCheck).repaint();
        showStatus("File loaded.");
        pack();
        indexCheck++;
    }
    
    private void slideShow() {
        fileChooser.setMultiSelectionEnabled(true);
        fileChooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
        int returnVal = fileChooser.showOpenDialog(this);
        if (allImagePanelImages.isEmpty()) {
           tabbedPane.remove(scrollPane);
        }
        
        if (returnVal != JFileChooser.APPROVE_OPTION) {
            return;
        }
        Timer timer = new Timer();
        File[] selectedFile = fileChooser.getSelectedFile().listFiles();
        for (int i = 0; i < selectedFile.length; i++) {
            if (selectedFile[i].getPath().endsWith(".png") ||
            selectedFile[i].getPath().endsWith(".jpg") ||
            selectedFile[i].getPath().endsWith(".gif")) {
            allImagePanelImages.add(ImageFileManager.loadImage(selectedFile[i]));
            allOriginalPanelImages.add(ImageFileManager.loadImage(selectedFile[i]));
        }
        else {
            for (int newI = 0; newI < selectedFile.length; newI++) {
                if (newI != i) {
                    selectedFile[newI] = selectedFile[newI];
                }
                else {
                    newI--;
                }
            }
        }
        }
        
        BoundedRangeModel myModel = new DefaultBoundedRangeModel() {
            public void setExtent(int value,
                        int extent,
                        int min,
                        int max,
                        boolean adjusting) {
                super.setRangeProperties(value, extent, min, max, adjusting);
            }
        };
        
        enableButtons(true);
        for (JMenuItem menuItem : menuItems) {
            menuItem.setEnabled(true);
        }
        
        if(allImagePanelImages.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                      "The files were not in a recognized image file format.",
                      "Image Load Error",
                      JOptionPane.ERROR_MESSAGE);
            enableButtons(false);
            for (JMenuItem menuItem : menuItems) {
            if (!(paramStrings.get(menuItem).equals("File") || 
                  paramStrings.get(menuItem).equals("Open") ||
                  paramStrings.get(menuItem).equals("Quit") ||
                  paramStrings.get(menuItem).equals("Slide Show"))) {
                menuItem.setEnabled(false);
            }
        } 
            return;
        }
        
        for (int i = 0; i < selectedFile.length; i++) {
            timer.schedule(new TimerTask() {
                @Override
                public void run() {
                if (checker.size() < selectedFile.length) {
                    
                    
                    ImagePanel panel = new ImagePanel();
                    setCurrentPanel(panel);
                    allImagePanels.get(indexCheck).setImage(allImagePanelImages.get(indexCheck));
                    allImagePanels.get(indexCheck).repaint();
                    tabbedPane.setSelectedIndex(indexCheck);
                    slider.setValue(indexCheck);
                    showStatus("File loaded.");
                    pack();
                    checker.push(indexCheck);
                    
                    myModel.setRangeProperties(indexCheck, selectedFile.length - 1, 0, selectedFile.length - 1, false);
                    slider.setModel(myModel);
                    slider.setMajorTickSpacing(indexCheck);
                    slider.setMinorTickSpacing(1);
                    slider.setPaintTicks(true);
                    
                    indexCheck++;
                }
                else {
                    timer.cancel();
                    timer.purge();
                }
                }
                }, 4000 * i);
        }
    }
    
    private void saveFile() {
        if (getCurrentImage() != null) {
            int returnVal = fileChooser.showSaveDialog(this);
            
            if (returnVal != JFileChooser.APPROVE_OPTION) {
                return; // cancelled.
            }
            File selectedFile = fileChooser.getSelectedFile();
            ImageFileManager.saveImage(getCurrentImage(), selectedFile);
            
            tabbedPane.remove(tabbedPane.getSelectedIndex());
            allImagePanels.remove(tabbedPane.getSelectedIndex());
            allImagePanelImages.remove(tabbedPane.getSelectedIndex());
            
            pastImages.clear();
            undoneImages.clear();
            
            showFilename(selectedFile.getPath());
            
            showStatus("File has been saved.");
        }
        else {
            showStatus("There is not an image to save...");
        }
    }
    
    /**
     * Close function: close the current image.
     */
    private void close() {
        if (getCurrentImage() != null) {
            int index = tabbedPane.getSelectedIndex();
            
            allImagePanelImages.remove(index);
            allOriginalPanelImages.remove(index);
            allImagePanels.remove(index);
            tabbedPane.remove(index);
            indexCheck--;
            
            showFilename(null);
            if (allImagePanelImages.isEmpty()) {
            enableButtons(false);
            for (JMenuItem menuItem : menuItems) {
                if (!(paramStrings.get(menuItem).equals("File") || 
                  paramStrings.get(menuItem).equals("Open") ||
                  paramStrings.get(menuItem).equals("Quit") ||
                  paramStrings.get(menuItem).equals("Slide Show"))) {
                      menuItem.setEnabled(false);
                }
            }
        }
            
            pastImages.clear();
            undoneImages.clear();
            
            showStatus("You have closed the image.");
        }
        else {
            showStatus("There is not an image to close...");
        }
    }
    
    /**
     * Quit function: quit the application.
     */
    private void quit() {
        System.exit(0);
    }
    
    /**
     * Rotates the picture no matter the length or width and then reframes the GUI.
     * @param num The degree to which the picture should be rotated.
     */
    private void rotate(int num) {
        num /= 90;
        priorImage = new OFImage(getCurrentImage());
        ImageViewer.pastImages.push(priorImage);
        
        
        for (int i = 0; i < num; i++) {
            int width = getCurrentImage().getWidth();
            int height = getCurrentImage().getHeight();
            
            OFImage eImage = new OFImage(height, width);
            for (int x = 0; x < width; x++) {
                for (int y = 0; y < height; y++) {
                    int newY = x;
                    int newX = height - 1 - y;
                    eImage.setPixel(newX, newY, getCurrentImage().getPixel(x, y));
                }
            }
            setCurrentImage(eImage);
            
            pack();
        }
        
        showStatus("Applied: rotation");
    }
    
    /**
     * Make the image half as tall and half as wide.
     */
    private void smallerButton() {
        if (getCurrentImage()  != null) {
            priorImage = new OFImage(getCurrentImage());
            ImageViewer.pastImages.push(priorImage);
            
            int width = getCurrentImage().getWidth()/2;
            int height = getCurrentImage().getHeight()/2;
            
            OFImage eImage = new OFImage(width, height);
            
            for (int x = 0; x < width; x++) {
                for (int y = 0; y < height; y++) {
                    eImage.setPixel(x, y, getCurrentImage().getPixel(x*2, y*2));
                }
            }
            
            setCurrentImage(eImage);
            
            repaint();
            pack();
            showStatus("Applied: smallerButton");
        }
        else {
            showStatus("No image loaded.");
        }
    }
    
    /**
     * Make the image 2x as tall and 2x as wide.
     */
    private void largerButton() {
        if (getCurrentImage()  != null) {
            priorImage = new OFImage(getCurrentImage());
            ImageViewer.pastImages.push(priorImage);
            int width = getCurrentImage().getWidth()*2;
            int height = getCurrentImage().getHeight()*2;
            
            OFImage eImage = new OFImage(width, height);
            
            for (int x = 0; x < width; x++) {
                for (int y = 0; y < height; y++) {
                    eImage.setPixel(x, y, getCurrentImage().getPixel(x / 2, y / 2));
                }
            }
            
            setCurrentImage(eImage);
            ImageViewer.pastImages.push(getCurrentImage());
            
            filters.get(6).apply(getCurrentImage());
            
            ImageViewer.pastImages.pop();
            
            int frameW = getWidth();
            int frameH = getHeight();
            
            pack();
            setSize(frameW, frameH);
            
            repaint();
            showStatus("Applied: largerButton");
            
        }
        else {
            showStatus("No image loaded.");
        }
    }
    
    /**
     * Apply a given filter to the current image.
     * @param filter The filter to be applied.
     */
    private void applyFilter(Filter filter) {
        OFImage currentImage = getCurrentImage();
        if (currentImage  != null) {
            priorImage = new OFImage(currentImage);
            ImageViewer.pastImages.push(priorImage);
            filter.apply(currentImage);
            repaint();
            showStatus("Applied: " + filter.getName());
        }
        else {
            showStatus("No image loaded.");
        }
    }
    
    private void slide() {
        if (slider.getMaximum() <= indexCheck) {
            tabbedPane.setSelectedIndex(slider.getValue());
        }
        else {
            //tabbedPane.setSelectedIndex(indexCheck);
        }
    }
    
    private void handleMouseClicked(MouseEvent e, JMenuItem i) {
        if (e.getButton() == MouseEvent.BUTTON1) {
            if ((e.getModifiers() & MouseEvent.SHIFT_MASK) == MouseEvent.SHIFT_MASK) {
                chooseNumber();
                if (currentNumber != 0) {
                    showStatus("You choose: " + currentNumber);
                }
            }
            else {
                if (paramStrings.get(i).equals("Multiple Undos")) {
                    multiUndo(currentNumber);
                }
                if (paramStrings.get(i).equals("Multiple Redos")) {
                    multiRedo(currentNumber);
                }
                showStatus("You performed multiple edits");
            }
        }
    }
    
    private void chooseNumber() {
        currentNumber = Integer.parseInt(JOptionPane.showInputDialog(this,
                    "Type an integer",
                    "How many times do you want to do this?",
                    JOptionPane.INFORMATION_MESSAGE));
    }
    
    /**
     * 'Pop' the previous version. This method prevents attempts at popping a previous version
     * if there are no more versions to pop.
     */
    private void undo() {
        if (!pastImages.isEmpty()) {
            ImageViewer.undoneImages.push(new OFImage(getCurrentImage()));
            setCurrentImage(ImageViewer.pastImages.pop());
            pack();
            showStatus("Undone.");
        }
        else {
            showStatus("There are no previous images.");
        }
    }
    
    private void multiUndo(int numOUndos) {
        numOUndos = (numOUndos > pastImages.size()) ? pastImages.size() : numOUndos;
        for (int i = 0; i < numOUndos; i++) {
            undo();
        }
    }
    
    /**
     * 'Pop' the undone version. This method prevents attempts at popping a previously
     * undone version if there are no more undone versions.
     */
    private void redo() {
        if (!undoneImages.isEmpty()) {
            ImageViewer.pastImages.push(new OFImage(getCurrentImage()));
            setCurrentImage(ImageViewer.undoneImages.pop());
            pack();
            showStatus("Redone.");
        }
        else {
            showStatus("There are no more versions that were undone.");
        }
    }
    
    private void multiRedo(int numORedos) {
        numORedos = (numORedos > pastImages.size()) ? undoneImages.size() : numORedos;
        for (int i = 0; i < numORedos; i++) {
            redo();
        }
    }
    
    /**
     * Restore the original version.
     */
    private void getOriginal() {
        if (getOriginalImage() != null) {
            setCurrentImage(getOriginalImage());
            pack();
            showStatus("Orignal");
        }
        else {
            showStatus("You have not chosen an image yet.");
        }
    }
    
    /**
     * Show the 'About...' dialog.
     */
    private void about() {
        JOptionPane.showMessageDialog(this,
                    "ImageViewer\n" + VERSION,
                    "About ImageViewer",
                    JOptionPane.INFORMATION_MESSAGE);
    }
    
    /**
     * Increase the number of pixels that are drawn on a press.
     */
    private void incrementBrushSize() {
        if (widthOStroke == 0 || heightOStroke == 0) {
            widthOStroke += 1;
            heightOStroke += 1;
        }
        else {
            widthOStroke *= 5;
            heightOStroke *= 5;
        }
    }
    
    /**
     * Decrease the number of pixels that are drawn on a press.
     */
    private void decrementBrushSize() {
        if (widthOStroke == 1 || heightOStroke == 1) {
            widthOStroke -= 1;
            heightOStroke -= 1;
        }
        else {
            widthOStroke /= 5;
            heightOStroke /= 5;
        }
    }
    
    /**
     * Draw a line.
     */
    private void draw() {
        if (getCurrentImage() != null && !row.isEmpty() && !col.isEmpty() && currentColor != null) {
            g = (Graphics2D) getCurrentImage().getGraphics();
            heightOStroke = 1;
            widthOStroke = 1;
            pastImages.push(getCurrentImage());
            
            g.setColor(currentColor);
            
            for (int i = 0; i < row.size() - 1; i++) {
                g.drawLine(row.get(i), col.get(i), row.get(i + 1), col.get(i + 1));
                getCurrentPanel().repaint();
            }
            
            if (!col.isEmpty() || !row.isEmpty()) {
                col.clear();
                row.clear();
            }
        }
    }
    
    /**
     * Handle mouse button pressed on the image.
     * @param e The mouse event object, providing details of the mouse press event.
     */
    private void handleMousePressed(MouseEvent e) {
        if (e.getButton() == MouseEvent.BUTTON1) {
            if ((e.getModifiers() & MouseEvent.SHIFT_MASK) == MouseEvent.SHIFT_MASK) {
                chooseColor();
                if (currentColor != null) {
                    showStatus("You choose: " + currentColor + " to color with.");
                }
            }
            else if (currentColor != null) {
                editImage(e);
            }
        }
    }
    
    /**
     * Choose a color for editing the picture.
     */
    private void chooseColor() {
        Color chosen = JColorChooser.showDialog(getCurrentPanel(), "Choose color", currentColor);
        if (chosen != null) {
            currentColor = chosen;
        }
    }
    
    /**
     * Edit the image using the given mouse event to determine
     * the location of the edit.
     * @param event The mouse event triggering the edit.
     */
    private void editImage(MouseEvent event) {
        if (getCurrentImage() != null && currentColor != null) {
            //Replace pixel at the current position with the currentColor.
            pastImages.push(new OFImage(getCurrentImage()));
            int x = event.getX();
            int y = event.getY();
            for (int ix = 0 - widthOStroke; ix <= widthOStroke; ix++) {
                for (int iy = 0 - heightOStroke; iy <= heightOStroke; iy++) {
                    if (x + ix > 0 && x + ix < getCurrentImage().getWidth() && y + iy > 0 &&
                        y + iy < getCurrentImage().getHeight()) {
                            getCurrentImage().setPixel(x + ix, y + iy, currentColor);
                    }
                }
            }
            row.add(x);
            col.add(y);
            getCurrentPanel().repaint();
            showStatus("You edited the image!");
        }
        else {
            showStatus("No image to edit.");
        }
    }
    
    // ---- support methods ----
    
    /**
     * allow methods to toggle the buttons from active to nonactive.
     * 
     * @param check 'true to enable all the buttons, 'false' to disable all of them.
     */
    private void enableButtons(boolean check) {
        smallerButton.setEnabled(check);
        largerButton.setEnabled(check);
    }
    
    /**
     * An accessor method for the priorImage.
     */
    public static OFImage getPriorImage() {
        priorImage = pastImages.peek();
        return priorImage;
    }
    
    /**
     * An accessor method for the originalImage.
     */
    public OFImage getOriginalImage() {
        //int index = (tabbedPane.getSelectedIndex() >= 0) ? tabbedPane.getSelectedIndex() : 0;
        return allOriginalPanelImages.get(tabbedPane.getSelectedIndex());
    }
    
    /**
     * Dipslay a status message in the frame's status bar.
     * @param text The status message to be displayed.
     */
    private void showStatus(String text) {
        statusLabel.setText(text);
    }
    
    private OFImage getCurrentImage() {
        int index = (tabbedPane.getSelectedIndex() >= 0) ? tabbedPane.getSelectedIndex() : 0;
        return allImagePanelImages.get(index);
    }
    
    private ImagePanel getCurrentPanel() {
        int index = (tabbedPane.getSelectedIndex() >= 0) ? tabbedPane.getSelectedIndex() : 0;
        return allImagePanels.get(index);
    }
    
    private void setCurrentImage(OFImage image) {
        allImagePanelImages.set(tabbedPane.getSelectedIndex(), new OFImage(image));
        allImagePanels.get(tabbedPane.getSelectedIndex()).setImage(allImagePanelImages.get(tabbedPane.getSelectedIndex()));
    }
    
    private void addPanel(ImagePanel panel) {
        int index = 0;
        allImagePanels.add(index, panel);
        allImagePanels.get(index).setBorder(new EtchedBorder());
        allImagePanels.get(index).addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent e) {handleMousePressed(e); }
        });
        scrollPane = new JScrollPane(allImagePanels.get(index));
        tabbedPane.add(scrollPane, indexCheck);
        contentPane.add(tabbedPane, BorderLayout.CENTER);
        repaint();
    }
    
    private void setCurrentPanel(ImagePanel panel) {
        allImagePanels.add(indexCheck, panel);
        allImagePanels.get(indexCheck).setBorder(new EtchedBorder());
        allImagePanels.get(indexCheck).addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent e) {handleMousePressed(e); }
        });
        scrollPane = new JScrollPane(allImagePanels.get(indexCheck));
        
        tabbedPane.add(scrollPane, indexCheck);
        contentPane.add(tabbedPane, BorderLayout.CENTER);
    }
    
    /**
     * Display a file name on the appropriate label.
     * @param filename the file name to be displayed.
     */
    private void showFilename(String filename) {
        if (filename == null) {
            filenameLabel.setText("No file displayed.");
        }
        else {
            filenameLabel.setText("File: " + filename);
        }
    }
    
    /**
     * Create and return a list with all the known filters.
     * @retyrn The list of filters.
     */
    private List<Filter> createFilters() {
        List<Filter> filterList = new ArrayList<>();
        filterList.add(new DarkerFilter("Darker"));
        filterList.add(new LighterFilter("Lighter"));
        filterList.add(new ThresholdFilter("Threshold"));
        filterList.add(new GrayscaleFilter("Grayscale"));
        filterList.add(new MirrorFilter("Mirror"));
        filterList.add(new InvertFilter("Invert"));
        filterList.add(new SmoothFilter("Smooth"));
        filterList.add(new SolarizeFilter("Solarize"));
        filterList.add(new EdgeDetectionFilter("EdgeDetection"));
        filterList.add(new FishEyeFilter("FishEye"));
        
        return filterList;
    }
}
