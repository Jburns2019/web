
/**
 * Write a description of class TestingInt here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class TestingInt
{
    // fields

    /**
     * Constructor for objects of class TestingInt
     */
    public TestingInt() {
        
    }
    
    public static int maxInt() {
        int x = 1;
        for (int i = 0; i <= 29; i++) {
            x <<= 1;
            x++;
        }
        return x;
    }
    
    public static void main(String[] args) {
        int x = 1;
        pr(x + "\n");
        x <<= 1;
        pr(x + "\n");
        x <<= 30;
        pr(x + "\n");
        x >>= 1;
        pr(x + "\n");
        x += 1;
        pr(x + "\n");
        int y = maxInt();
        pr(y + "\n");
        pr(printBits(x | y));
        pr(printBits(-1));
        short z = -1;
        pr(printBits(z));
        z = 48;
        pr(printBits(z));
    }
    
    public static String printBits(int x) {
        char[] bits = new char[32];
        
        pr("printBits x os " + x);
        int index = 31;
        
        for (int mask = 1; mask != 0; mask <<= 1) {
            bits[index--] = (mask & x) == 0 ? '0' : '1';
        }
        pr("\n");
        
        return new String(bits) + "\n";
    }
    
    private static void pr(int x) {
        System.out.print(x);
    }
    
    private static void pr(String x) {
        System.out.print(x);
    }
}
