import java.awt.Color;
/**
 * Write a description of class SolarizeFilter here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class SolarizeFilter extends Filter
{
    /**
     * Constructor for objects of class DarkerFilter
     * @param name The name of the filter.
     */
    public SolarizeFilter(String name) {
        super(name);
    }
    
    /**
     * Apply this filter to an image.
     * @param image The image to be changed by this filter.
     */
    public void implementFilter(OFImage image) {
        for (int xVal = 0; xVal < image.getWidth(); xVal++) {
            for (int yVal = 0; yVal < image.getHeight(); yVal++) {
                int redVal = image.getPixel(xVal, yVal).getRed();
                int greenVal = image.getPixel(xVal, yVal).getGreen();
                int blueVal = image.getPixel(xVal, yVal).getBlue();
        
                redVal = (redVal < 128) ? 255 - redVal : redVal;
                greenVal = (greenVal < 128) ? 255 - greenVal : greenVal;
                blueVal = (blueVal < 128) ? 255 - blueVal : blueVal;
        
                image.setPixel(xVal, yVal, new Color(redVal, greenVal, blueVal));
            }
        }
    }
}
