
/**
 * Write a description of class DarkerFilter here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class DarkerFilter extends Filter
{
    /**
     * Constructor for objects of class DarkerFilter
     * @param name The name of the filter.
     */
    public DarkerFilter(String name) {
        super(name);
    }
    
    /**
     * Apply this filter to an image.
     * @param image The image to be changed by this filter.
     */
    public void implementFilter(OFImage image) {
        for (int xVal = 0; xVal < image.getWidth(); xVal++) {
            for (int yVal = 0; yVal < image.getHeight(); yVal++) {
                image.setPixel(xVal, yVal, image.getPixel(xVal, yVal).darker());
            }
        }
    }
}
